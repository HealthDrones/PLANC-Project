/** Automatically generated file. DO NOT MODIFY */
package fpa.projeto.navegador;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}